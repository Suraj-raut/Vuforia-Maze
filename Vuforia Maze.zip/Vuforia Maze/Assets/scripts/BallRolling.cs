using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Vuforia;


public class BallRolling : MonoBehaviour
{
	
	public GameObject Plane;
	public GameObject spawnPoint;
	
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
       if(transform.position.y < Plane.transform.position.y -10 )
	   {
		   transform.position = spawnPoint.transform.position;
	   }
    }
}
